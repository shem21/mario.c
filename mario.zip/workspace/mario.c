#include <cs50.h>
#include <stdio.h>

int main (void)
{   // Get positive integer from user
int n;
do
{
n =get_int("Width: ");
}
 while  (n <8);
 // print out that many hashes
 for (int i =0; i < n; i++);
 {
 printf("?");
 }
 printf("\n");

}
